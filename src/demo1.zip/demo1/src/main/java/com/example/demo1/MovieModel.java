package com.example.demo1;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class MovieModel {
    public ObservableList<Movie> allMoviesList() throws SQLException {
        String query = "select * from movies";
        ResultSet rs = Database.ExecureQ(query);
        return rsToList(rs);
    }
    public Movie getMovie(String id) throws SQLException {
        String query = "select * from movies where movie_id=?";
        PreparedStatement statement = Database.getStatement(query);
        statement.setInt(1,Integer.parseInt(id));
        ResultSet rs=statement.executeQuery();
        return rsToList(rs).get(0);
    }

    private ObservableList<Movie> rsToList(ResultSet rs) throws SQLException {
        ObservableList<Movie> movieList = FXCollections.observableArrayList();
        Movie movie;
        while (rs.next()) {
            movie = new Movie(rs.getInt(1), rs.getString(2),
                    rs.getString(3), rs.getString(4), rs.getString(5),
                    rs.getString(6), rs.getBinaryStream(7));
            movieList.add(movie);
        }
        return movieList;
    }

}

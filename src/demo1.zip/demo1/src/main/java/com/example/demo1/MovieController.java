package com.example.demo1;

import javafx.collections.ObservableList;
import javafx.event.Event.*;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.GridPane;


import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.ResourceBundle;

public class MovieController implements Initializable {

    @FXML
    private GridPane mygrid;

    public static Movie selectedMovie;

    MovieModel movieModel=new MovieModel();

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        try {
            ObservableList<Movie> movies = movieModel.allMoviesList();
            for(int i=0;i<2;i++){
                for (int j = 0; j < 2; j++) {
                    ImageView imageView=new ImageView(new Image(movies.get(i+j*2).getImage()));
                    imageView.setId(movies.get(i+j*2).getId().toString());
                    imageView.setPreserveRatio(true);
                    imageView.setFitHeight(150);
                    imageView.setOnMouseClicked(eventHandler);
                    mygrid.add(imageView,i,j);
                }
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }
    EventHandler<MouseEvent> eventHandler = mouseEvent -> {
        ImageView source = (ImageView) mouseEvent.getSource();
        try {
            selectedMovie = movieModel.getMovie(source.getId());
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        try {
            HelloApplication.changeScene("MovieDetails");
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    };

}
package com.example.demo1;

import java.io.InputStream;

public class Movie {
    private Integer id;
    private String title;
    private String price;
    private String genre;
    private String summary;
    private String director;
    private InputStream image;

    public Movie(Integer id, String title, String price, String genre, String summary, String director, InputStream image) {
        this.id = id;
        this.title = title;
        this.price = price;
        this.genre = genre;
        this.summary = summary;
        this.director = director;
        this.image = image;
    }

    public Integer getId() {
        return id;
    }

    public String getTitle() {
        return title;
    }

    public String getPrice() {
        return price;
    }

    public String getGenre() {
        return genre;
    }

    public String getSummary() {
        return summary;
    }

    public String getDirector() {
        return director;
    }

    public InputStream getImage() {
        return image;
    }

}